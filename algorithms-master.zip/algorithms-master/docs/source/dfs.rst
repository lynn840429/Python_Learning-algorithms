.. role:: hidden
    :class: hidden-section

algorithms.dfs
=================
