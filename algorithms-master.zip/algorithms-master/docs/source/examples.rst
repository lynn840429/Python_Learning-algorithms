.. role:: hidden
    :class: hidden-section

Examples
=================
